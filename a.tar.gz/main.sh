LD_LIBRARY_PATH=/usr/local/MATLAB/R2014b/sys/os/glnxa64:/usr/local/MATLAB/R2014b/bin/glnxa64:/usr/local/MATLAB/R2014b/runtime/glnxa64:/home/changyoung/hdd/workspace/use-matlab/src ./main
